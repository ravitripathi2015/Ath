import mysql.connector
from time import gmtime, strftime
n=strftime("%a, %d %b %Y", gmtime())
n=str(n)
today=n[5:]
print(' ','________________!!!SATAYAM THEATRES WELLCOMES YOU!!!__________________')
print()
print(' ',n)
print()
while True :
    try :
        conn = mysql.connector.connect(host = 'localhost',user='root',passwd='1234',database='theatre')
        c1=conn.cursor()
        print("PRESS 1 -> REGISTER")
        print("PRESS 2 -> LOGIN")
        print("PRESS 3 -> CHECK YOUR BOOKING DETAILS")
        print("PRESS 4 -> TO DELETE YOUR ACCOUNT")
        choice = int(input("ENTER YOUR CHOICE : "))
        if choice == 1 :
            fname = input("ENTER FIRST NAME : ")
            lname = input("ENTER LAST NAME : ")
            mobile = int(input("MOBILE NUMBER : "))
            number=mobile
            count=0
            while(number>0):
                count=count+1
                number=number//10
            if count==10:
                password = input("CREATE YOUR PASSWORD:")
                number= str(mobile)
                c1.execute("insert into login values('{}', '{}', '{}','{}')".format(fname, lname, number,password))
                print("YOU ARE SUCESSFULLY REGISTERED")
                conn.commit()
            else:
                print("PLEASE ENTER CORRECT NUMBER")
        elif choice == 2 :
            mobile = int(input("MOBILE NUMBER : "))
            c1.execute("select * from login")
            for data in c1 :
                if data[2] == str(mobile):
                    password = input("ENTER YOUR PASSWORD:")
                    if data[3]==password:
                        print("WELCOME : ", data[0], " ", data[1], " to SATYAM THEATRES")
                        print("DO YOU WANT TO BOOK FIRST CLASS OR SECOND CLASS SEAT ?")
                        print("TYPE 1-> FIRST CLASS")
                        print("TYPE 2-> SECOND CLASS")
                        choice_class = int(input("ENTER THE CHOICE:"))
                        if choice_class == 1:
                            number=str(mobile)
                            class1="FIRST"
                            film = input("ENTER THE FILM NAME : ")
                            total_tic = input("HOW MANY TICKETS? : ")
                            snacks = input("ANYTHING TO EAT OR DRINK ?: ")
                            print("PRESS 1 -> MORNING")
                            print("PRESS 2 -> AFTERNOON")
                            print("PRESS 3 -> EVENING")
                            time_slot = int(input("SELECT TIME SLOT:"))
                            if time_slot==1:
                                time="MORNING"
                                c1.execute("insert into bookingdetail values('{}','{}','{}','{}','{}','{}')".format(class1,film,total_tic,snacks,number,time))
                                conn.commit()
                            elif time_slot==2:
                                time="AFTERNOON"
                                c1.execute("insert into bookingdetail values('{}','{}','{}','{}','{}','{}')".format(class1,film,total_tic,snacks,number,time))
                                conn.commit()
                            elif time_slot==3:
                                time="EVENING"
                                c1.execute("insert into bookingdetail values('{}','{}','{}','{}','{}','{}')".format(class1,film,total_tic,snacks,number,time))
                                conn.commit()
                            print("YOUR MOVIE TICKETS ARE SUCCESFULLY BOOKED ,THANKYOU VISIT AGAIN !!")
                        elif choice_class == 2:
                            number=str(mobile)
                            class1="SECOND"
                            film = input("ENTER THE FILM NAME : ")
                            total_tic = input("HOW MANY TICKETS? : ")
                            snacks = input("ANYTHING TO EAT OR DRINK ?: ")
                            print("PRESS 1 -> MORNING")
                            print("PRESS 2 -> AFTERNOON")
                            print("PRESS 3 -> EVENING")
                            time_slot = int(input("SELECT TIME SLOT:"))
                            if time_slot==1:
                                time="MORNING"
                                c1.execute("insert into bookingdetail values('{}','{}','{}','{}','{}','{}')".format(class1,film,total_tic,snacks,number,time))
                                conn.commit()
                            elif time_slot==2:
                                time="AFTERNOON"
                                c1.execute("insert into bookingdetail values('{}','{}','{}','{}','{}','{}')".format(class1,film,total_tic,snacks,number,time))
                                conn.commit()
                            elif time_slot==3:
                                time="EVENING"
                                c1.execute("insert into bookingdetail values('{}','{}','{}','{}','{}','{}')".format(class1,film,total_tic,snacks,number,time))
                                conn.commit()
                            print("YOUR MOVIE TICKETS ARE SUCCESFULLY BOOKED ,THANKYOU VISIT AGAIN !!")
                    else:
                        print("YOU HAVE ENTERED WRONG PASSWORD, PLEASE TRY AGAIN")
        elif choice == 3 :
            mobile=int(input("MOBILE NUMBER : "))
            c1.execute("select * from login")
            for data in c1:
                if data[2] == str(mobile):
                    password = input("ENTER YOUR PASSWORD:")
                    if data[3]==password:
                        print("HI ", data[0], " ", data[1])
                        c1.execute("select * from bookingdetail")
                        for i in c1 :
                            if str(mobile)== i[4] :
                                total_tic=int(i[2])
                                print("YOU HAVE BOOKED FOR FILM ", i[1], " AND NUMBER OF TICKETS ARE ", i[2],"WITH SNACKS",i[3],"AT",i[5],".")
                                if i[0]=="FIRST":
                                    print()
                                    print("PRICE FOR EVERY FIRST CLASS TICKET IS ₹1500.")
                                    print()
                                    print("THERE IS 18% GST ON MOVIE TICKET.")
                                    print()
                                    print("PAYMENT OF SNACKS WILL CHARGED SEPRATELY,WHEN THE ORDER IS DELEVERED.")
                                    print()
                                    price=1.18*1500*total_tic
                                    print("TOTAL PRICE=",price)
                                if i[0]=="SECOND":
                                    print()
                                    print("PRICE FOR EVERY SECOND CLASS TICKET IS ₹850")
                                    print()
                                    print("THERE IS 18% GST ON MOVIE TICKET")
                                    print()
                                    print("PAYMENT OF SNACKS WILL CHARGED SEPRATELY,WHEN THE ORDER IS DELEVERED")
                                    print()
                                    price=1.18*850*total_tic
                                    print("TOTAL PRICE=",price)
                    else:
                        print("YOU HAVE ENTERED WRONG PASSWORD, PLEASE TRY AGAIN")                
                        input("PRESS ENTER")
        elif choice == 4:
            mobile = int(input("MOBILE NUMBER : "))
            c1.execute("select * from login")
            for data in c1 :
                if data[2] == str(mobile):
                    password = input("ENTER YOUR PASSWORD:")
                    if data[3]==password:
                        c1.execute("delete from login where MOBILE_NUMBER="+str(mobile)+";")
                        c1.execute("delete from bookingdetail where MOBILE_NUMBER="+str(mobile)+";")
                        conn.commit()
                        print()
                        print("****************************SUCCESSFULLY ACCOUNT DELETED****************************")
                    else:
                        print("YOU HAVE ENTERED WRONG PASSWORD, PLEASE TRY AGAIN")                
                        input("PRESS ENTER TO CONTINUE")
        else:
            print("YOU HAVE ENTERED WRONG CHOICE")
            input("PRESS ENTER TO CONTINUE")
    except Exception as e :
        print("ERROR IN CONNECTING TO DATABASE")
        input("PRESS ENTER TO CONTINUE")
    
