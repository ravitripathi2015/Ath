import mysql.connector
try :
    mydb = mysql.connector.connect(host="localhost",user="root",password="1234")
    mycursor = mydb.cursor()
    mycursor.execute("CREATE DATABASE theatre")
    conn = mysql.connector.connect(host = 'localhost',user='root',passwd='1234',database='theatre')
    c1=conn.cursor()
    c1.execute("use theatre")
    c1.execute("create table login(FIRST_NAME varchar(100),LAST_NAME varchar(100),MOBILE_NUMBER varchar(10) primary key,PASSWORD varchar(100))")
    c1.execute("create table bookingdetail(CLASS varchar(100),FLIM varchar(100),TOTAL_TIC bigint(100),SNACKS varchar(100),MOBILE_NUMBER varchar(10),TIME varchar(100))")
    mydb.commit()
    print("SUCESSFUL")
    input("PRESS ENTER") 
except Exception as e :
    print(e)
