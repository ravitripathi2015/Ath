import mysql.connector
try :
    mydb = mysql.connector.connect(host="localhost",user="root",password="1234")
    mycursor = mydb.cursor()
    mycursor.execute("CREATE DATABASE theatre")
    conn = mysql.connector.connect(host = 'localhost',user='root',passwd='1234',database='theatre')
    c1=conn.cursor()
    c1.execute("use theatre")
    c1.execute("create table login(fname varchar(100),lname varchar(100),mobile bigint,password varchar(100))")
    c1.execute("create table bookingdetail(class1 varchar(100),flim varchar(100),total_tic varchar(100),snacks varchar(100),contact bigint)")
    mydb.commit()
    print("SUCESSFUL")
except Exception as e :
    print(e)
