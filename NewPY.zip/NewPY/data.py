import mysql.connector as sql
while True : 
    try :
        mydb = sql.connect(host="localhost",user="root",password="1234")
        mycursor = mydb.cursor()
        mycursor.execute("CREATE DATABASE travel_booking")
        conn = sql.connect(host='localhost', user='root', passwd='1234', database='travel_booking')
        c1 = conn.cursor()
        c1.execute("create table login(phone varchar(100) primary key not null, name varchar(100), password varchar(100))")
        c1.execute("create table travel_details(location varchar(100), destination varchar(100), time varchar(100), driver varchar(100), urgency varchar(100), phone varchar(100))")
        print("DATABASES CREATED SUCCESSFULLY")
        input("")
    except Exception as e :
        print(e)
        input("")


