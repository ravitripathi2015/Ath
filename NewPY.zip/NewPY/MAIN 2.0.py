import mysql.connector
while True :
    try :
        conn = mysql.connector.connect(host = 'localhost',user='root',passwd='1234',database='theatre')
        c1=conn.cursor()
        print("PRESS 1 -> REGISTER")
        print("PRESS 2 -> LOGIN")
        print("PRESS 3 -> CHECK YOUR BOOKING DETAILS")
        choice = int(input("ENTER YOUR CHOICE : "))
        if choice == 1 :
            fname = input("ENTER FIRST NAME : ")
            lname = input("ENTER LAST NAME : ")
            mobile = int(input("MOBILE NUMBER : "))
            count=0
            while(mobile>0):
                count=count+1
                mobile=mobile//10
            if count==10:
                password = input("CREATE YOUR PASSWORD:")
                c1.execute("insert into login values('{}', '{}', '{}','{}')".format(fname, lname, mobile,password))
                print("YOU ARE SUCESSFULLY REGISTERED")
                conn.commit()
            else:
                print("PLEASE ENTER CORRECT NUMBER")
        elif choice == 2 :
            mobile = int(input("MOBILE NUMBER : "))
            password = input("ENTER YOUR PASSWORD:")
            c1.execute("select * from login")
            for data in c1 :
                if data[2] == mobile and data[3]==password:
                    print("WELCOME : ", data[0], " ", data[1], " to SATYAM THEATRES")
                    print("DO YOU WANT TO BOOK FIRST CLASS OR SECOND CLASS SEAT ?")
                    print("TYPE 1-> FIRST CLASS")
                    print("TYPE 2-> SECOND CLASS")
                    choice_class = int(input("ENTER THE CHOICE:"))
                    if choice_class == 1:
                        contact= mobile
                        class1="FIRST"
                        film = input("ENTER THE FILM NAME : ")
                        total_tic = input("HOW MANY TICKETS? : ")
                        snacks = input("ANYTHING TO EAT OR DRINK ? ")
                        c1.execute("insert into bookingdetail values('{}','{}','{}','{}','{}')".format(class1,film,total_tic,snacks,contact))
                        conn.commit()
                        print("YOUR MOVIE TICKETS ARE SUCCESFULLY BOOKED ,THANKYOU VISIT AGAIN !!")
                    elif choice_class == 2:
                        contact= mobile
                        class1="SECOND"
                        film = input("ENTER THE FILM NAME : ")
                        total_tic = input("HOW MANY TICKETS? : ")
                        snacks = input("ANYTHING TO EAT OR DRINK ? ")
                        c1.execute("insert into bookingdetail values('{}','{}','{}','{}','{}')".format(class1,film,total_tic,snacks,contact))
                        conn.commit()
                        print("YOUR MOVIE TICKETS ARE SUCCESFULLY BOOKED ,THANKYOU VISIT AGAIN !!")
        elif choice == 3 :
            mobile = int(input("MOBILE NUMBER : "))
            password = input("ENTER YOUR PASSWORD:")
            c1.execute("select * from login")
            for data in c1:
                if data[2] == mobile and data[3]==password:
                    print("HI ", data[0], " ", data[1])
                    c1.execute("select * from bookingdetail")
                    for i in c1 :
                        if mobile== i[4] :
                            print("YOU HAVE BOOKED FOR FILM ", i[1], " AND NUMBER OF TICKETS ARE ", i[2])

            input("PRESS ENTER")

    except Exception as e :
        print("ERROR IN CONNECTING TO DATABASE")
        input("PRESS ENTER TO CONTINUE")
