import mysql.connector as sql
import sys
conn=sql.connect(host='localhost',user='root',password='1234',database='travel_booking')
c1=conn.cursor()
from time import gmtime, strftime
n=strftime("%a, %d %b %Y", gmtime())
n=str(n)
today=n[5:]
print(' ','________MVP TRAVELLES welcomes U!!!!!!__________')
print()
print(' ',n)
print()

while True :
    print()
    print('Press 1 to CREATE ACCOUNT')
    print('Press 2 LOGIN')
    print("press 3 delete account")
    print('Press 4 to Exit')
    print()
    choice = int(input("enter choice : "))
    if choice == 1 :
        phone_number = int(input('Phone Number : '))
        number=phone_number
        count=0
        while(number>0):
                count=count+1
                number=number//10
        if count==10:
            name = str(input('Name : '))
            password = str(input('password : '))
            c1.execute("insert into login(phone,name,password)values(" + str(phone_number)+",'"+name+"','"+password+"')")
            conn.commit()
            print('Account sucessfully Created')
            continue
        else:
            print("PLEASE ENTER CORRECT NUMBER")    
    elif choice == 2 :
        print()
        phone = int(input('Enter your phone number='))
        c1.execute("select * from login where phone = " + str(phone) + ";")
        data = c1.fetchall()
        print("WELCOME: ", data[0][1])
        password = input("PLEASE ENTER THE PASSWORD : ")
        while True :
            if password == data[0][2] :
                print("WELCOME")
                print('12.Book for a ride')
                print('13.Bill verification')
                print('14.My travel log')

                print()

                choice1 = int(input('Enter Your Choice='))
                if choice1 == 12:
                    your_location = input('Your_location=')
                    your_destination = input('Your_destination=')
                    time = input('time to start board=')
                    driver = input("driver gender preferences=")
                    urgency = input('urgency(yes/no)=')
                    phone_number = str(phone)
                    mySql_insert_query = """INSERT INTO travel_details(location, destination, time, driver, urgency,phone) VALUES (%s, %s, %s, %s, %s, %s) """
                    record = (your_location, your_destination, time, driver, urgency, phone_number)
                    c1.execute(mySql_insert_query, record)
                    conn.commit()
                    print("RIDE BOOKED")
                elif choice1 == 13 :
                    Dist = int(input('distance travelled [km]='))
                    bill = Dist * 5
                    print('your payment =Rs.', bill)
                elif choice1 == 14:
                    phone = input("ENTER PHONE NUMBER : ")
                    c1.execute("select * from travel_details where phone like '" + str(phone) + "';")
                    data = c1.fetchall()
                    print(data)
                    sys.exit()
                else:
                    print("wrong choice")
                    continue
    elif choice==3:
        c1.execute("delete from login where phone="+str(phone_number)+";")
        c1.execute("delete from travel_details where phone="+str(phone_number)+";")
        conn.commit()
        print()
        print("**************************************SUCCESSFULLY ACCOUNT DELETED**************************************")
        
    else:
        print("WRONG CHOICE")
        continue

